import datetime as dt
import pandas_datareader.data as web
import os
import yfinance as yf
 
yf.pdr_override()

#銘柄コード入力(7177はGMO-APです。)
ticker_symbol="7177"
ticker_symbol_dr=ticker_symbol + ".T"
 
#2022-01-01以降の株価取得
start='2022-01-01'
end = dt.date.today()
 
#データ取得
df = web.get_data_yahoo(ticker_symbol_dr, start=start, end=end)
#df = web.DataReader(ticker_symbol_dr, data_source='yahoo', start=start,end=end)
#2列目に銘柄コード追加
df.insert(0, "code", ticker_symbol, allow_duplicates=False)
#csv保存
df.to_csv( os.path.dirname(__file__) + '\y_stock_data_'+ ticker_symbol + '.csv')

import pandas_datareader.data as web
import datetime as dt
import pandas as pd
import yfinance as yf
 
yf.pdr_override()

""" 
tickers = ["7177", "7176"]# = pd.read_csv("code.csv",index_col=0,header=0) # "コード","企業名"という形式を想定
 
start   = dt.datetime(2013,1,1)
end     = dt.date.today()
 
symbols = []
for ticker in tickers:
    symbol = str(ticker) + ".T"
    symbols.append(symbol)
 
df = web.get_data_yahoo(tickers=symbols,start=start,end=end)
 
#df.to_csv( "y_stock_data.csv")
df.to_csv(os.path.dirname(__file__) + '\y_stock_data' + '.csv')
"""