#import numpy as np
#import pandas as pd
import matplotlib.pyplot as plt
from prophet import Prophet
import pandas_datareader.data as web
import datetime
import yfinance as yf
 
yf.pdr_override()

start = datetime.date(2018, 1, 1)
end = datetime.date(2022, 1, 1)
symbol='9983.T'
#df = DataReader('9983.T', 'yahoo', start, end)
df = web.get_data_yahoo(symbol, start, end)
#
df['ds'] = df.index
df = df.rename({'Close':'y'}, axis=1)

print(df.info())

# 不要カラムの削除と並べ替え
df = df[['ds', 'y']]

print(df.info())

# 学習データとテストデータの分割
df_train = df.loc[:'2021-01-01']
df_test = df.loc['2021-01-01':]

print(df_train.info())

params = {'growth': 'linear',
          'changepoints': None,
          'n_changepoints': 25,
          'changepoint_range': 0.8,
          'yearly_seasonality': 'auto',
          'weekly_seasonality': 'auto',
          'daily_seasonality': 'auto',
          'holidays': None,
          'seasonality_mode': 'additive',
          'seasonality_prior_scale': 10.0,
          'holidays_prior_scale': 10.0,
          'changepoint_prior_scale': 0.05,
          'mcmc_samples': 0,
          'interval_width': 0.80,
          'uncertainty_samples': 1000,
          'stan_backend': None
         }

# Prophet 予測モデル構築
df_prophet_model = Prophet(**params)
df_prophet_model.fit(df_train)

# Prophet 予測モデルの精度検証用データの生成
df_future = df_prophet_model.make_future_dataframe(periods=len(df_test), freq='d')
df_pred = df_prophet_model.predict(df_future)

df_pred['yhat']

# Prophet 予測モデルの予測結果（学習データ期間＋テストデータ期間）
df_pred_plot = df_prophet_model.plot(df_pred)         #予想値（黒い点は学習データの実測値）
df_pmpc = df_prophet_model.plot_components(df_pred)   #モデルの要素分解（トレンド、週周期、年周期）

# テストデータに予測値を結合
df_test.loc[:, 'Prophet Predict'] = df_pred['yhat'][-245:].to_list()