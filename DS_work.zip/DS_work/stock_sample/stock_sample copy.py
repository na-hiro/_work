import yfinance as yf

# yf.download(対象の株銘柄, 期間, 頻度)

ticker = "AMZN"

data = yf.download(ticker, period="6mo", interval="1d")
print(data)


#ライブラリのインポート
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import itertools
#from pandas import datetime
from datetime import datetime 

import pandas_datareader.data as web
import datetime as dt
import yfinance as yf
 
yf.pdr_override()
 
ticker = "7203"
symbol = ticker + ".T"
 
start  = dt.datetime(2016,3,1)
end    = dt.date.today()
 
df = web.get_data_yahoo(tickers=symbol,start=start,end=end)
#df = web.DataReader(symbol,data_source='yahoo', start=start, end=end )
print(df)
df.to_csv( "y_stock_data_"+ticker+".csv")

TOYOTA_stock_Sorce = pd.read_csv("y_stock_data_7203.csv")
print(df)

#終値の抽出
TOYOTA_stock=TOYOTA_stock_Sorce['Close']  
print(TOYOTA_stock)

#indexに期間を設定
index=pd.date_range("2016-03-01","2024-01-05",freq="M")
print(index)

#indexをTOYOTA_stockのインデックスに代入
TOYOTA_stock.index=index

#データパターンの確認
sm.tsa.seasonal_decompose(TOYOTA_stock,freq=12).plot()
plt.show()


fig=plt.figure(figsize=(9,7))

#自己相関係数の可視化
ax1=fig.add_subplot(211)
fig=sm.graphics.tsa.plot_acf(TOYOTA_stock,ax=ax1)

#偏自己相関係数の可視化
ax2=fig.add_subplot(212)
fig=sm.graphics.tsa.plot_pacf(TOYOTA_stock,ax=ax2)

plt.show()
