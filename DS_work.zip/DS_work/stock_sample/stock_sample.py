import yfinance as yf
import matplotlib.pyplot as plt
# yf.download(対象の株銘柄, 期間, 頻度)

ticker = "AMZN"

data = yf.download(ticker, start="2022-12-01", end="2022-12-31", interval="1d")
data

df = data
df = df.drop("Volume", axis=1)

plt.figure(figsize=(15, 5))
plt.plot(df.index, df)
plt.legend(df)
plt.show()
print(data)