# we will use numpy and matplotlib for all the following examples
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import pywt
from skimage.restoration import denoise_wavelet
import pywt

def doppler(freqs, dt, amp_inc=10, t0=0, f0=np.pi*2):
    t = np.arange(len(freqs)) * dt + t0
    amp = np.linspace(1, np.sqrt(amp_inc), len(freqs))**2
    sig = amp * np.sin(freqs * f0 * t)
    return t,sig

def noisify(sig, noise_amp=1):
    return sig + (np.random.random(len(sig))-0.5)*2*noise_amp

def maddest(d, axis=None):
    return np.mean(np.absolute(d - np.mean(d, axis)), axis)
    
def denoise(x, wavelet='db', level=1):
    coeff = pywt.wavedec(x, wavelet, mode="per")
    sigma = (1/0.6745) * maddest(coeff[-level])

    uthresh = sigma * np.sqrt(2*np.log(len(x)))
    coeff[1:] = (pywt.threshold(i, value=uthresh, mode='hard') for i in coeff[1:])

    return pywt.waverec(coeff, wavelet, mode='per')

t_dop, sig_dop = doppler(np.arange(10,20,0.01)[::-1], 0.002)
sig_dop_n2 = noisify(sig_dop, noise_amp=2)
plt.figure(figsize=(16,4))
plt.subplot(121)
plt.plot(t_dop, sig_dop)
plt.title("original signal")
plt.subplot(122)
plt.plot(t_dop, sig_dop_n2)
plt.title("noisy signal")
plt.show()
plt.close()

# ノイズ除去
#ecg = pywt.data.ecg()
#xd_noise = denoise_wavelet(sig_dop_n2, sigma=2.86, wavelet='sym5', wavelet_levels=6)
xd_noise = denoise_wavelet(sig_dop_n2, sigma=1, wavelet='sym5', wavelet_levels=6)

#xd_noise = pywt.denoise_wavelet(sig_dop_n2, wavelet="sym8", mode="soft", wavelet_levels=3, method="base_shrink", rescale_sigma=True)

# グラフのプロット
plt.figure(figsize=(10, 6))
plt.plot(sig_dop_n2, label="Noisy ECG Signal")
plt.plot(xd_noise, label="Denoised ECG Signal")
plt.xlabel("Time")
plt.ylabel("Amplitude")
plt.legend()
plt.show()