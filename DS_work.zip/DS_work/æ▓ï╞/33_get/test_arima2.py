import yfinance as yf
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import itertools
#from pandas import datetime

#ターゲットを指定
#ticker = "AMZN"
#ticker = "7203.T"
ticker = "4755.T"

#データを収集
TOYOTA_stock_Sorce = yf.download(ticker , period='max', interval = "1mo")
print(TOYOTA_stock_Sorce)

TOYOTA_stock=TOYOTA_stock_Sorce['Close']  
print(type(TOYOTA_stock))

df_TOYOTA_stock = pd.DataFrame(TOYOTA_stock)
#print(df_TOYOTA_stock.set_index('Date'))
print(df_TOYOTA_stock)

#データパターンの確認
sm.tsa.seasonal_decompose(df_TOYOTA_stock, period=12).plot()
plt.show()

fig=plt.figure(figsize=(9,7))

#自己相関係数の可視化
ax1=fig.add_subplot(211)
fig=sm.graphics.tsa.plot_acf(df_TOYOTA_stock,ax=ax1)

#偏自己相関係数の可視化
ax2=fig.add_subplot(212)
fig=sm.graphics.tsa.plot_pacf(df_TOYOTA_stock,ax=ax2)
plt.close()
plt.show()

#--
#(p,d,q)(sp,sd,sq)を求める
def selectparameter(DATA,s):
    p=d=q=range(0,2)
    pdq=list(itertools.product(p,d,q))
    seasonal_pdq=[(x[0],x[1],x[2],s) for x in list(itertools.product(p,d,q))]
    parameters=[]
    BICs=np.array([])
    for param in pdq:
        for param_seasonal in seasonal_pdq:
            try:
                mod=sm.tsa.statespace.SARIMAX(DATA,order=param,seasonal_order=param_seasonal)
                results=mod.fit()
                parameters.append([param,param_seasonal,results.bic])
                BICs=np.append(BICs,results.bic)
            except:
                continue
    return print(parameters[np.argmin(BICs)])

selectparameter(df_TOYOTA_stock,12) 
plt.close()

#モデルの構築
SARIMA_TOYOTA_stock=sm.tsa.statespace.SARIMAX(df_TOYOTA_stock,order=(1,1,0),seasonal_order=(0,1,1,12)).fit()
TOYOTA_stock_pred=SARIMA_TOYOTA_stock.predict("2020-11-01","2027-12-01")
plt.plot(TOYOTA_stock_pred)
plt.show()

#元の時系列データと予測データの比較
plt.plot(df_TOYOTA_stock)
plt.plot(TOYOTA_stock_pred,color="r")
plt.show
print("end")