import warnings
warnings.filterwarnings('ignore')

#ライブラリのimport
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#データフレーム表示用関数
from IPython.display import display

#表示オプション調整
#NumPyの浮動少数点の表示精度
np.set_printoptions(suppress=True, precision=4)
#pandasでの浮動少数点の表示精度
pd.options.display.float_format = '{:.4f}'.format
#データフレームですべての項目を表示
pd.set_option("display.max_columns",None)
#グラフのデフォルトフォント設定
plt.rcParams["font.size"] = 14
#乱数の種
random_seed = 123

#'''
#データの読み込み
df= pd.read_csv('33 Sectors of Nikkei at November.csv')
#df= pd.read_csv('33 Sectors of Nikkei with Nikkei225 at November.csv')
print(df.head())

df = df.dropna(how='any', axis=1)
df = df.drop("日付", axis=1)
print(df.head())

df_clustering = df
#'''

from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
#'''
sc = StandardScaler()
df_clustering_sc = sc.fit_transform(df_clustering)

kmeans = KMeans(n_clusters=5, random_state=0)
clusters = kmeans.fit(df_clustering_sc)
df_clustering["cluster"] = clusters.labels_
print(df_clustering["cluster"].unique())
print(df_clustering.head())
#'''

from sklearn.decomposition import PCA
#'''
X = df_clustering_sc
pca = PCA(n_components=2)
pca.fit(X)
x_pca = pca.transform(X)
pca_df = pd.DataFrame(x_pca)
pca_df["cluster"] = df_clustering["cluster"]

for i in df_clustering["cluster"].unique():
    tmp = pca_df.loc[pca_df["cluster"]==i]
    plt.scatter(tmp[0], tmp[1])

#plt.show()

df.index = ["水産・農業","鉱業", "建設業", "食料品", "繊維製品","パルプ・紙","化学", "医薬品", "石油・石炭商品", "ゴム製品", "ガラス・土石製品","鉄鋼", "非鉄金属", "機械", "電気機器","輸送用機器","精密機器", "その他製造", "卸売業", "小売業","銀行業","証券・商品先物取引業", "保険業", "その他金融業", "不動産業","陸運業","海運業", "空運業", "倉庫・運輸業", "情報・通信業", "電気・ガス業","サービス業", "金属製品"]
df_s = df.sort_values(by="cluster")
print(df_s["cluster"])
#'''

#データの読み込み
df_new= pd.read_csv('33 Sectors of Nikkei with Nikkei225 at November.csv')
df_new.tail()

df_new = df_new.dropna(how='any', axis=1)
df_new = df_new.drop("日付", axis=1)
df_new.tail()

df_clustering2 = df_new

from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
df_clustering_sc2 = sc.fit_transform(df_clustering2)

kmeans = KMeans(n_clusters=5, random_state=0)
clusters = kmeans.fit(df_clustering_sc2)
df_clustering2["cluster"] = clusters.labels_
print(df_clustering2["cluster"].unique())
print(df_clustering2.head())

from sklearn.decomposition import PCA
X = df_clustering_sc2
pca = PCA(n_components=2)
pca.fit(X)
x_pca = pca.transform(X)
pca_df2 = pd.DataFrame(x_pca)
pca_df2["cluster"] = df_clustering2["cluster"]
df_s2 = pca_df2.sort_values("cluster")

for i in df_clustering2["cluster"].unique():
    tmp = pca_df2.loc[pca_df2["cluster"]==i]
    plt.scatter(tmp[0], tmp[1])